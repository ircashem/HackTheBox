﻿
Public Class SsoIntegration

    Public Property Username As String
    Public Property Password As String



End Class
